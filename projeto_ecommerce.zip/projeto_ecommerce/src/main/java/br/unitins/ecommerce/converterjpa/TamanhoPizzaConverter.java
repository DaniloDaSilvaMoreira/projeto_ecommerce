package br.unitins.ecommerce.converterjpa;

import jakarta.persistence.AttributeConverter;
import jakarta.persistence.Converter;

import br.unitins.ecommerce.model.produto.pizza.TamanhoPizza;

@Converter(autoApply = true)
public class TamanhoPizzaConverter implements AttributeConverter <TamanhoPizza, Integer> {

    @Override
    public Integer convertToDatabaseColumn(TamanhoPizza tamanhoPizza) {
        return tamanhoPizza == null ? null : tamanhoPizza.getId();
    }

    @Override
    public TamanhoPizza convertToEntityAttribute(Integer id) {
        return TamanhoPizza.valueOf(id);
    }
}
