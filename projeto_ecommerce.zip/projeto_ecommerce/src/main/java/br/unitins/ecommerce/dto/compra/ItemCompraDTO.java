package br.unitins.ecommerce.dto.compra;

public record ItemCompraDTO(
    Long idProduto,
    Integer quantidade
) {

}
