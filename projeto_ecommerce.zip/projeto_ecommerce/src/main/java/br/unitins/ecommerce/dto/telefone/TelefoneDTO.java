package br.unitins.ecommerce.dto.telefone;

public record TelefoneDTO(
    String codigoArea,

    String numero
) {
    
}
