package br.unitins.ecommerce.dto.usuario.perfil;

public record AuthUsuarioDTO (

    String login,
    String senha
) {

}