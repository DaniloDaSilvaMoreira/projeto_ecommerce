package br.unitins.ecommerce.service.hash;

public interface HashService {

    public String getHashSenha(String senha);
}
