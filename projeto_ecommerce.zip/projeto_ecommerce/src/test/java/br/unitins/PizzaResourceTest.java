package br.unitins;

import static io.restassured.RestAssured.given;
import static org.hamcrest.CoreMatchers.is;
import static org.hamcrest.CoreMatchers.notNullValue;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.junit.jupiter.api.Assertions.assertNull;

import java.util.ArrayList;
import java.util.List;

import jakarta.inject.Inject;

import io.quarkus.test.junit.QuarkusTest;
import io.quarkus.test.security.TestSecurity;
import io.restassured.http.ContentType;

import org.junit.jupiter.api.Test;

import br.unitins.ecommerce.dto.pizza.PizzaDTO;
import br.unitins.ecommerce.dto.pizza.PizzaResponseDTO;
import br.unitins.ecommerce.model.produto.pizza.TamanhoEmbalagem;
import br.unitins.ecommerce.model.produto.pizza.TamanhoPizza;
import br.unitins.ecommerce.service.pizza.PizzaService;

@QuarkusTest
public class PizzaResourceTest {
    
    @Inject
    PizzaService pizzaService;

    @Test
    @TestSecurity(user = "testUser", roles = {"Admin"})
    public void getAllTest() {

        given()
                .when().get("/pizzas")
                .then()
                .statusCode(200);
    }

    /*************************************************************** */
    @Test
    @TestSecurity(user = "testUser", roles = {"Admin"})
    public void insertTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        given()
            .contentType(ContentType.JSON)
            .body(pizza)
            .when().post("/pizzas")
            .then()
                .statusCode(201)
                .body("id", notNullValue(), "nome", 
                is("CalabrezaMista"),
                "bordaPizza", is("Catupiry"),"preco",
                is(70.0F),"estoque", is("Disponivel"), 
                "tamanhoPizza.label", is("Media"),
                "tamanhoEmbalagem.label", is("Media"),
                "categoria.label", is("Salgada"),
                "sabores.get(0)", is("Calabreza"),
                "sabores.get(1)", is("Frango"));
                
    }
    /*************************************************************** */

    @Test
    @TestSecurity(user = "testUser", roles = {"User"})
    public void insertForbiddenTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMistaaa",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        given()
                .contentType(ContentType.JSON)
                .body(pizza)
                .when().post("/pizzas")
                .then()
                .statusCode(403);
    }

    @Test
    public void insertUnauthorizedTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMistay",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        given()
                .contentType(ContentType.JSON)
                .body(pizza)
                .when().post("/pizzas")
                .then()
                .statusCode(401);
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"Admin"})
    public void updateTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(4l);
        sabores.add(5l);

        PizzaDTO pizza = new PizzaDTO(
            "DoceMista",
            "Chocolate ao leite",
                1l, 
                70.0,
                20,
                1,
                1,
                1,
                sabores);

        Long id = pizzaService.insert(pizza).id();

        PizzaDTO pizzaUpdate = new PizzaDTO(
            "DoceMista",
            "Chocolate ao leite",
                2l, 
                70.0,
                20,
                3,
                3,
                1,
                sabores);

        given()
          .contentType(ContentType.JSON)
          .body(pizzaUpdate)
          .when().put("/pizzas/" + id)
          .then()
             .statusCode(204);

        PizzaResponseDTO pizzaResponse = pizzaService.getById(id);

assertThat(pizzaResponse.nome(), is("DoceMista"));
assertThat(pizzaResponse.bordaPizza(), is("Chocolate ao leite"));
assertThat(pizzaResponse.nomeMarca(), is("Seara"));
assertThat(pizzaResponse.preco(), is(70.0));
assertThat(pizzaResponse.estoque(), is("Disponivel"));
assertThat(pizzaResponse.tamanhoPizza(), is(TamanhoPizza.GRANDE));
assertThat(pizzaResponse.tamanhoEmbalagem(), is(TamanhoEmbalagem.GRANDE_35X35));
assertThat(pizzaResponse.categoria().getLabel(), is("Doce"));
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"Admin"})
    public void deleteTest() {

        List<Long> sabores = new ArrayList<>();
        sabores.add(1l);
        sabores.add(2l);
        PizzaDTO pizza = new PizzaDTO(
            "CalabrezaMista",
            "Catupiry",
                1l, 
                70.0,
                20,
                2,
                2,
                2,
                sabores);

        Long id = pizzaService.insert(pizza).id();

        given()
          .when().delete("/pizzas/" + id)
          .then()
             .statusCode(204);

        PizzaResponseDTO pizzaResponse = null;

        try {
            
            pizzaResponse =  pizzaService.getById(id);
        } catch (Exception e) {

        }
        finally {
            assertNull(pizzaResponse);   
        }
    }

     @Test
     @TestSecurity(user = "testUser", roles = {"Admin"})
    public void countTest() {

        given()
            .when().get("/pizzas/count")
            .then()
                .statusCode(200);
    }

     @Test
    public void getByIdTest() {

        given()
            .when().get("/pizzas/" + 1)
            .then()
                .statusCode(200);
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"User"})
    public void getByNomeTest() {

        given()
            .when().get("/pizzas/searchByNome/" + "pizza")
            .then()
                .statusCode(200);
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"User"})
    public void getByCategoriaTest() {

        given()
            .when().get("/pizzas/searchByCategoria/" + 1)
            .then()
                .statusCode(200);
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"User"})
    public void getByTamanhoEmbalagemTest() {

        given()
            .when().get("/pizzas/searchByTamanhoEmbalagem/" + 1)
            .then()
                .statusCode(200);
    }

    @Test
    @TestSecurity(user = "testUser", roles = {"User"})
    public void getByTamanhoPizzaTest() {

        given()
            .when().get("/pizzas/searchByTamanhoPizza/" + 1)
            .then()
                .statusCode(200);
    }

    @Test
    public void getByMarcaTest() {

        given()
            .when().get("/pizzas/searchByMarca/" + "Pizza Hut")
            .then()
                .statusCode(200);
    }

    /*************************************************************** */
    @Test
    public void filterByPrecoMinTest() {

        given()
                .when().get("/pizzas/filterByPrecoMin/" + 60.0)
                .then()
                .statusCode(200);

    }

    @Test
    public void filterByPrecoMaxTest() {

        given()
                .when().get("/pizzas/filterByPrecoMax/" + 160.0)
                .then()
                .statusCode(200);

    }

      @Test
    public void filterByEntrePrecoTest() {

        given()
                .when().get("/pizzas/filterByEntrePreco/" + 60.0 + "/" + 160.0)
                .then()
                .statusCode(200);

    }
}

